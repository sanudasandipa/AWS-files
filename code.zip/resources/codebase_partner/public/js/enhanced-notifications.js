/**
 * Enhanced Notification System
 * Modern, accessible, and user-friendly notification system
 */

class NotificationSystem {
    constructor() {
        this.notifications = new Map();
        this.config = {
            duration: 5000,
            maxNotifications: 5,
            position: 'top-right',
            animations: true,
            showErrors: false, // Disable error notifications by default
            debugMode: window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1'
        };
        this.init();
    }

    init() {
        // Create notification containers
        this.createContainers();
        
        // Initialize styles if not already loaded
        this.loadStyles();
        
        console.log('🔔 Enhanced Notification System initialized');
    }

    createContainers() {
        // Create inline alert container
        if (!document.getElementById('notificationContainer')) {
            const container = document.createElement('div');
            container.id = 'notificationContainer';
            container.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                z-index: 9999;
                pointer-events: none;
            `;
            document.body.appendChild(container);
        }

        // Create progress overlay
        if (!document.getElementById('progressOverlay')) {
            const overlay = document.createElement('div');
            overlay.id = 'progressOverlay';
            overlay.className = 'progress-overlay';
            overlay.innerHTML = `
                <div class="progress-content">
                    <div class="progress-spinner"></div>
                    <h5 id="progressTitle">Processing...</h5>
                    <p id="progressMessage">Please wait while we process your request.</p>
                </div>
            `;
            document.body.appendChild(overlay);
        }
    }

    loadStyles() {
        if (!document.getElementById('notification-styles')) {
            const link = document.createElement('link');
            link.id = 'notification-styles';
            link.rel = 'stylesheet';
            link.href = '/css/notifications.css';
            document.head.appendChild(link);
        }
    }

    /**
     * Show a notification
     * @param {string} message - The notification message
     * @param {string} type - The notification type (success, error, warning, info)
     * @param {Object} options - Additional options
     */
    show(message, type = 'info', options = {}) {
        const config = { ...this.config, ...options };
        const id = this.generateId();
        
        const notification = this.createNotification(id, message, type, config);
        this.displayNotification(notification, config);
        
        // Auto remove
        if (config.duration > 0) {
            setTimeout(() => {
                this.remove(id);
            }, config.duration);
        }
        
        return id;
    }

    /**
     * Show a success notification
     */
    success(message, options = {}) {
        return this.show(message, 'success', options);
    }

    /**
     * Show an error notification - less intrusive than before
     */
    error(message, options = {}) {
        // Check if error notifications are enabled
        if (!this.config.showErrors && !this.config.debugMode) {
            console.warn('Error notification suppressed:', message);
            return null;
        }
        
        // Only show error notifications for specific, actionable errors
        // Avoid generic "refresh page" messages
        if (message && !message.includes('refresh') && !message.includes('reload') && !message.includes('persist')) {
            return this.show(message, 'error', { duration: 6000, ...options });
        }
        
        // Log generic errors to console instead of bothering users
        if (this.config.debugMode) {
            console.warn('Generic error suppressed:', message);
        }
        return null;
    }

    /**
     * Show a warning notification
     */
    warning(message, options = {}) {
        return this.show(message, 'warning', { duration: 6000, ...options });
    }

    /**
     * Show an info notification
     */
    info(message, options = {}) {
        return this.show(message, 'info', options);
    }

    /**
     * Show a confirmation dialog
     */
    confirm(message, options = {}) {
        return new Promise((resolve) => {
            const config = {
                title: 'Confirm Action',
                confirmText: 'Confirm',
                cancelText: 'Cancel',
                type: 'warning',
                ...options
            };

            const overlay = this.createConfirmationOverlay(message, config, resolve);
            document.body.appendChild(overlay);
            
            // Show overlay
            setTimeout(() => {
                overlay.classList.add('show');
            }, 10);
        });
    }

    /**
     * Show loading overlay
     */
    showLoading(message = 'Processing...', title = 'Please wait') {
        const overlay = document.getElementById('progressOverlay');
        const titleEl = document.getElementById('progressTitle');
        const messageEl = document.getElementById('progressMessage');
        
        if (titleEl) titleEl.textContent = title;
        if (messageEl) messageEl.textContent = message;
        
        overlay.classList.add('show');
        
        return {
            hide: () => this.hideLoading(),
            updateMessage: (newMessage) => {
                if (messageEl) messageEl.textContent = newMessage;
            },
            updateTitle: (newTitle) => {
                if (titleEl) titleEl.textContent = newTitle;
            }
        };
    }

    /**
     * Hide loading overlay
     */
    hideLoading() {
        const overlay = document.getElementById('progressOverlay');
        overlay.classList.remove('show');
    }

    /**
     * Show inline status message
     */
    showStatus(message, type = 'info', targetElement = null) {
        const statusEl = document.createElement('div');
        statusEl.className = `status-message ${type}`;
        
        const icons = {
            success: 'fa-check-circle',
            error: 'fa-exclamation-circle',
            warning: 'fa-exclamation-triangle',
            info: 'fa-info-circle'
        };
        
        statusEl.innerHTML = `
            <i class="fas ${icons[type]}"></i>
            ${message}
        `;
        
        if (targetElement) {
            // Insert after target element
            targetElement.parentNode.insertBefore(statusEl, targetElement.nextSibling);
        } else {
            // Add to main content area
            const mainContent = document.querySelector('.main-content, .container, main');
            if (mainContent) {
                mainContent.insertBefore(statusEl, mainContent.firstChild);
            }
        }
        
        // Auto remove after 5 seconds
        setTimeout(() => {
            if (statusEl.parentNode) {
                statusEl.remove();
            }
        }, 5000);
        
        return statusEl;
    }

    /**
     * Create notification element
     */
    createNotification(id, message, type, config) {
        const notification = document.createElement('div');
        notification.id = id;
        notification.className = `inline-alert ${type}`;
        notification.style.pointerEvents = 'auto';
        
        const icons = {
            success: 'fa-check-circle',
            error: 'fa-exclamation-circle',
            warning: 'fa-exclamation-triangle',
            info: 'fa-info-circle'
        };
        
        notification.innerHTML = `
            <div style="padding: 1rem 1.5rem; display: flex; align-items: center; justify-content: space-between;">
                <div style="display: flex; align-items: center;">
                    <i class="fas ${icons[type]}" style="margin-right: 0.75rem; font-size: 1.2rem;"></i>
                    <span>${message}</span>
                </div>
                <button type="button" class="btn-close" onclick="notifications.remove('${id}')" 
                        style="background: none; border: none; font-size: 1.2rem; cursor: pointer; opacity: 0.7; margin-left: 1rem;">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        `;
        
        this.notifications.set(id, notification);
        return notification;
    }

    /**
     * Display notification
     */
    displayNotification(notification, config) {
        const container = document.getElementById('notificationContainer');
        
        // Limit number of notifications
        const existing = container.children;
        if (existing.length >= config.maxNotifications) {
            // Remove oldest notification
            const oldest = existing[0];
            if (oldest) {
                oldest.remove();
            }
        }
        
        container.appendChild(notification);
        
        // Trigger animation
        setTimeout(() => {
            notification.classList.add('show');
        }, 10);
    }

    /**
     * Create confirmation overlay
     */
    createConfirmationOverlay(message, config, resolve) {
        const overlay = document.createElement('div');
        overlay.className = 'confirmation-overlay';
        
        const iconClass = config.type === 'error' ? 'danger' : config.type;
        const icons = {
            warning: 'fa-exclamation-triangle',
            danger: 'fa-exclamation-circle',
            info: 'fa-info-circle'
        };
        
        overlay.innerHTML = `
            <div class="confirmation-card">
                <div class="confirmation-icon ${iconClass}">
                    <i class="fas ${icons[iconClass] || icons.warning}"></i>
                </div>
                <h4 class="text-center mb-3">${config.title}</h4>
                <p class="text-center mb-4">${message}</p>
                <div class="d-flex gap-3 justify-content-center">
                    <button type="button" class="btn btn-secondary px-4" onclick="this.closest('.confirmation-overlay').remove(); (${resolve})(false)">
                        ${config.cancelText}
                    </button>
                    <button type="button" class="btn btn-${config.type === 'danger' ? 'danger' : 'primary'} px-4" onclick="this.closest('.confirmation-overlay').remove(); (${resolve})(true)">
                        ${config.confirmText}
                    </button>
                </div>
            </div>
        `;
        
        // Close on backdrop click
        overlay.addEventListener('click', (e) => {
            if (e.target === overlay) {
                overlay.remove();
                resolve(false);
            }
        });
        
        // Close on escape key
        const escapeHandler = (e) => {
            if (e.key === 'Escape') {
                overlay.remove();
                resolve(false);
                document.removeEventListener('keydown', escapeHandler);
            }
        };
        document.addEventListener('keydown', escapeHandler);
        
        return overlay;
    }

    /**
     * Remove notification
     */
    remove(id) {
        const notification = this.notifications.get(id);
        if (notification) {
            notification.classList.remove('show');
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.remove();
                }
                this.notifications.delete(id);
            }, 300);
        }
    }

    /**
     * Clear all notifications
     */
    clear() {
        this.notifications.forEach((notification, id) => {
            this.remove(id);
        });
    }

    /**
     * Generate unique ID
     */
    generateId() {
        return 'notification-' + Date.now() + '-' + Math.random().toString(36).substr(2, 9);
    }
}

// Form Enhancement Utilities
class FormEnhancer {
    constructor() {
        this.init();
    }

    init() {
        this.enhanceAllForms();
        console.log('📝 Form Enhancement System initialized');
    }

    enhanceAllForms() {
        const forms = document.querySelectorAll('form');
        forms.forEach(form => this.enhanceForm(form));
    }

    enhanceForm(form) {
        // Add loading states to submit buttons
        form.addEventListener('submit', (e) => {
            const submitBtn = form.querySelector('button[type="submit"], input[type="submit"]');
            if (submitBtn) {
                this.setButtonLoading(submitBtn, true);
                
                // Remove loading state after form submission
                setTimeout(() => {
                    this.setButtonLoading(submitBtn, false);
                }, 3000);
            }
        });

        // Enhanced validation feedback
        const inputs = form.querySelectorAll('input, textarea, select');
        inputs.forEach(input => {
            input.addEventListener('blur', () => {
                this.validateInput(input);
            });
            
            input.addEventListener('input', () => {
                if (input.classList.contains('is-invalid')) {
                    this.validateInput(input);
                }
            });
        });
    }

    setButtonLoading(button, isLoading) {
        if (isLoading) {
            button.classList.add('btn-loading');
            button.disabled = true;
            button.dataset.originalText = button.innerHTML;
        } else {
            button.classList.remove('btn-loading');
            button.disabled = false;
            if (button.dataset.originalText) {
                button.innerHTML = button.dataset.originalText;
            }
        }
    }

    validateInput(input) {
        const value = input.value.trim();
        let isValid = true;
        let message = '';

        // Required validation
        if (input.hasAttribute('required') && !value) {
            isValid = false;
            message = `${this.getFieldLabel(input)} is required`;
        }

        // Email validation
        if (input.type === 'email' && value) {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(value)) {
                isValid = false;
                message = 'Please enter a valid email address';
            }
        }

        // Phone validation
        if (input.type === 'tel' && value) {
            const phoneRegex = /^[\+]?[1-9][\d]{0,15}$/;
            if (!phoneRegex.test(value.replace(/[\s\-\(\)]/g, ''))) {
                isValid = false;
                message = 'Please enter a valid phone number';
            }
        }

        this.updateInputFeedback(input, isValid, message);
        return isValid;
    }

    updateInputFeedback(input, isValid, message) {
        // Remove existing classes
        input.classList.remove('is-valid', 'is-invalid');
        
        // Remove existing feedback
        const existingFeedback = input.parentNode.querySelector('.form-feedback');
        if (existingFeedback) {
            existingFeedback.remove();
        }

        if (!isValid && message) {
            input.classList.add('is-invalid');
            
            const feedback = document.createElement('div');
            feedback.className = 'form-feedback error';
            feedback.innerHTML = `<i class="fas fa-exclamation-circle"></i>${message}`;
            input.parentNode.appendChild(feedback);
        } else if (input.value.trim()) {
            input.classList.add('is-valid');
            
            const feedback = document.createElement('div');
            feedback.className = 'form-feedback success';
            feedback.innerHTML = `<i class="fas fa-check-circle"></i>Looks good!`;
            input.parentNode.appendChild(feedback);
        }
    }

    getFieldLabel(input) {
        const label = document.querySelector(`label[for="${input.id}"]`);
        if (label) {
            return label.textContent.replace('*', '').trim();
        }
        
        return input.name || input.placeholder || 'This field';
    }
}

// Initialize systems
const notifications = new NotificationSystem();
const formEnhancer = new FormEnhancer();

// Export for global use
window.notifications = notifications;
window.formEnhancer = formEnhancer;

// Legacy support
window.showToast = (message, type, duration) => notifications.show(message, type, { duration });
window.showNotification = (message, type) => notifications.show(message, type);
window.showLoading = (message, title) => notifications.showLoading(message, title);
window.hideLoading = () => notifications.hideLoading();

console.log('✨ Enhanced Notification & Form System loaded successfully!');
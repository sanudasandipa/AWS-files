// Student Management System - Enhanced UI JavaScript

// Document Ready Function
document.addEventListener('DOMContentLoaded', function() {
    // Initialize all components
    initializeSearch();
    initializeFormValidation();
    initializeTooltips();
    initializeAnimations();
});

// Search functionality for student table
function initializeSearch() {
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.addEventListener('keyup', function() {
            const filter = this.value.toLowerCase();
            const table = document.getElementById('studentsTable');
            const rows = table.getElementsByClassName('student-row');
            
            for (let i = 0; i < rows.length; i++) {
                const row = rows[i];
                const name = row.querySelector('.student-name').textContent.toLowerCase();
                const email = row.querySelector('.email-link').textContent.toLowerCase();
                const city = row.querySelector('td:nth-child(3)').textContent.toLowerCase();
                
                if (name.includes(filter) || email.includes(filter) || city.includes(filter)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            }
        });
    }
}

// Form validation enhancement
function initializeFormValidation() {
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            const requiredFields = form.querySelectorAll('input[required]');
            let isValid = true;
            
            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    field.classList.add('is-invalid');
                    isValid = false;
                } else {
                    field.classList.remove('is-invalid');
                }
            });
            
            // Email validation
            const emailField = form.querySelector('input[type="email"]');
            if (emailField && emailField.value) {
                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (!emailRegex.test(emailField.value)) {
                    emailField.classList.add('is-invalid');
                    isValid = false;
                } else {
                    emailField.classList.remove('is-invalid');
                }
            }
            
            if (!isValid) {
                e.preventDefault();
                showNotification('Please fill in all required fields correctly.', 'error');
            }
        });
        
        // Remove invalid class on input
        const inputs = form.querySelectorAll('input');
        inputs.forEach(input => {
            input.addEventListener('input', function() {
                this.classList.remove('is-invalid');
            });
        });
    });
}

// Initialize tooltips (if using Bootstrap 5)
function initializeTooltips() {
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    if (typeof bootstrap !== 'undefined') {
        tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    }
}

// Add smooth animations
function initializeAnimations() {
    // Fade in animation for cards
    const cards = document.querySelectorAll('.card-style, .feature-card, .stat-card, .help-card');
    cards.forEach((card, index) => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        
        setTimeout(() => {
            card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
        }, index * 100);
    });
}

// Utility functions
function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `alert alert-${type} notification-toast`;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 9999;
        max-width: 300px;
        opacity: 0;
        transform: translateX(100%);
        transition: all 0.3s ease;
    `;
    
    notification.innerHTML = `
        <i class="fas fa-${type === 'error' ? 'exclamation-triangle' : 'info-circle'} me-2"></i>
        ${message}
    `;
    
    document.body.appendChild(notification);
    
    // Show notification
    setTimeout(() => {
        notification.style.opacity = '1';
        notification.style.transform = 'translateX(0)';
    }, 100);
    
    // Hide notification after 5 seconds
    setTimeout(() => {
        notification.style.opacity = '0';
        notification.style.transform = 'translateX(100%)';
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 300);
    }, 5000);
}

// Export data functionality
function exportData() {
    const table = document.getElementById('studentsTable');
    if (!table) return;
    
    let csv = 'Name,Address,City,State,Email,Phone\n';
    const rows = table.querySelectorAll('.student-row');
    
    rows.forEach(row => {
        const cells = row.querySelectorAll('td, th');
        const rowData = [];
        
        // Extract data from each cell (excluding actions column)
        for (let i = 0; i < cells.length - 1; i++) {
            let cellText = cells[i].textContent.trim();
            // Clean up email and phone links
            if (cellText.includes('@')) {
                cellText = cellText.replace(/^.*?([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}).*$/, '$1');
            }
            if (cellText.includes('+') || cellText.match(/^\d/)) {
                cellText = cellText.replace(/^.*?([\d\s\+\-\(\)]+).*$/, '$1').trim();
            }
            rowData.push(`"${cellText}"`);
        }
        
        csv += rowData.join(',') + '\n';
    });
    
    // Download CSV
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'students.csv';
    a.click();
    window.URL.revokeObjectURL(url);
    
    showNotification('Student data exported successfully!', 'success');
}

// Refresh data functionality
function refreshData() {
    showNotification('Refreshing student data...', 'info');
    // Simulate refresh
    setTimeout(() => {
        window.location.reload();
    }, 1000);
}

// View student details (placeholder)
function viewStudent(studentId) {
    showNotification(`Viewing details for student ID: ${studentId}`, 'info');
    // This would typically open a modal or navigate to a detail page
}

// Add CSS for invalid inputs
const style = document.createElement('style');
style.textContent = `
    .is-invalid {
        border-color: #dc3545 !important;
        box-shadow: 0 0 0 3px rgba(220, 53, 69, 0.1) !important;
    }
    
    .notification-toast {
        border-radius: 8px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        border: none;
    }
    
    .alert-success {
        background: linear-gradient(135deg, rgba(39, 174, 96, 0.1), rgba(39, 174, 96, 0.05));
        border-left: 4px solid #27ae60;
        color: #27ae60;
    }
    
    .alert-error {
        background: linear-gradient(135deg, rgba(231, 76, 60, 0.1), rgba(231, 76, 60, 0.05));
        border-left: 4px solid #e74c3c;
        color: #e74c3c;
    }
`;
document.head.appendChild(style);
// Student Management System - Enhanced UI JavaScript
// Modern, feature-rich JavaScript for improved user experience

// Global configuration
const CONFIG = {
    ANIMATION_DURATION: 300,
    NOTIFICATION_DURATION: 5000,
    SEARCH_DEBOUNCE: 300,
    COUNTER_ANIMATION_DURATION: 2000
};

// Document Ready Function
document.addEventListener('DOMContentLoaded', function() {
    console.log('🚀 Student Management System - UI Enhanced');
    
    // Initialize all components
    initializeSearch();
    initializeFormValidation();
    initializeTooltips();
    initializeAnimations();
    initializeCounters();
    initializeFilters();
    initializeTableSorting();
    initializeDateDisplay();
    initializeKeyboardShortcuts();
    
    // Add CSS for enhanced features
    addEnhancedStyles();
});

// ====== ENHANCED SEARCH FUNCTIONALITY ======
function initializeSearch() {
    const searchInput = document.getElementById('searchInput');
    const clearSearchBtn = document.getElementById('clearSearch');
    
    if (searchInput) {
        let searchTimeout;
        
        // Debounced search
        searchInput.addEventListener('keyup', function() {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                performSearch(this.value);
            }, CONFIG.SEARCH_DEBOUNCE);
        });
        
        // Clear search functionality
        if (clearSearchBtn) {
            clearSearchBtn.addEventListener('click', function() {
                searchInput.value = '';
                performSearch('');
                searchInput.focus();
            });
        }
        
        // Enter key to focus first result
        searchInput.addEventListener('keydown', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                const firstVisibleRow = document.querySelector('.student-row:not([style*="display: none"])');
                if (firstVisibleRow) {
                    firstVisibleRow.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    firstVisibleRow.classList.add('highlight-row');
                    setTimeout(() => {
                        firstVisibleRow.classList.remove('highlight-row');
                    }, 2000);
                }
            }
        });
    }
}

function performSearch(filter) {
    const filterLower = filter.toLowerCase();
    const table = document.getElementById('studentsTable');
    const rows = document.querySelectorAll('.student-row');
    const filterInfo = document.getElementById('filterInfo');
    const filterResultsText = document.getElementById('filterResultsText');
    
    let visibleCount = 0;
    let totalCount = rows.length;
    
    rows.forEach(row => {
        const searchableText = getRowSearchableText(row);
        const isVisible = searchableText.includes(filterLower);
        
        if (isVisible) {
            row.style.display = '';
            visibleCount++;
            // Highlight matching text
            highlightSearchTerm(row, filter);
        } else {
            row.style.display = 'none';
        }
    });
    
    // Update filter info
    if (filterInfo && filterResultsText) {
        if (filter.trim()) {
            filterInfo.classList.remove('d-none');
            filterResultsText.textContent = `Showing ${visibleCount} of ${totalCount} students matching "${filter}"`;
        } else {
            filterInfo.classList.add('d-none');
        }
    }
    
    // Update table stats
    updateTableStats(visibleCount, totalCount);
    
    // Show no results message if needed
    toggleNoResultsMessage(visibleCount === 0 && filter.trim());
}

function getRowSearchableText(row) {
    const nameEl = row.querySelector('.student-name');
    const emailEl = row.querySelector('.email-link');
    const phoneEl = row.querySelector('.phone-link');
    const cityEl = row.querySelector('.location-badge');
    const stateEl = row.querySelector('.state-text');
    const addressEl = row.querySelector('.address-text');
    
    const texts = [
        nameEl?.textContent || '',
        emailEl?.textContent || '',
        phoneEl?.textContent || '',
        cityEl?.textContent || '',
        stateEl?.textContent || '',
        addressEl?.textContent || ''
    ];
    
    return texts.join(' ').toLowerCase();
}

function highlightSearchTerm(row, term) {
    if (!term.trim()) return;
    
    const elements = row.querySelectorAll('.student-name, .email-link, .phone-link, .location-badge, .state-text, .address-text');
    elements.forEach(el => {
        const original = el.textContent;
        const highlighted = original.replace(new RegExp(`(${term})`, 'gi'), '<mark>$1</mark>');
        if (highlighted !== original) {
            el.innerHTML = highlighted;
        }
    });
}

// ====== ENHANCED FORM VALIDATION ======
function initializeFormValidation() {
    const forms = document.querySelectorAll('form');
    
    forms.forEach(form => {
        const submitButton = form.querySelector('button[type="submit"]');
        const validationSummary = document.getElementById('validationSummary');
        const validationErrors = document.getElementById('validationErrors');
        
        // Real-time validation
        const inputs = form.querySelectorAll('input, select, textarea');
        inputs.forEach(input => {
            input.addEventListener('blur', () => validateField(input));
            input.addEventListener('input', () => {
                input.classList.remove('is-invalid');
                if (validationSummary) {
                    validationSummary.classList.add('d-none');
                }
            });
        });
        
        // Form submission validation
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const errors = validateForm(form);
            
            if (errors.length === 0) {
                // Show loading state
                showFormLoading(submitButton, true);
                
                // Simulate processing delay
                setTimeout(() => {
                    form.submit();
                }, 500);
            } else {
                // Show validation errors
                displayValidationErrors(errors, validationSummary, validationErrors);
                
                // Focus first invalid field
                const firstInvalid = form.querySelector('.is-invalid');
                if (firstInvalid) {
                    firstInvalid.focus();
                    firstInvalid.scrollIntoView({ behavior: 'smooth', block: 'center' });
                }
                
                showToast('Please correct the highlighted fields', 'error');
            }
        });
    });
}

function validateField(field) {
    const errors = [];
    const value = field.value.trim();
    const fieldName = field.name || field.id || 'field';
    
    // Required field validation
    if (field.hasAttribute('required') && !value) {
        errors.push(`${capitalizeFirst(fieldName)} is required`);
    }
    
    // Email validation
    if (field.type === 'email' && value) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(value)) {
            errors.push('Please enter a valid email address');
        }
    }
    
    // Phone validation
    if (field.type === 'tel' && value) {
        const phoneRegex = /^[\+]?[1-9][\d]{0,15}$/;
        if (!phoneRegex.test(value.replace(/[\s\-\(\)]/g, ''))) {
            errors.push('Please enter a valid phone number');
        }
    }
    
    // Name validation
    if (field.name === 'name' && value) {
        if (value.length < 2) {
            errors.push('Name must be at least 2 characters long');
        }
    }
    
    // Update field appearance
    if (errors.length > 0) {
        field.classList.add('is-invalid');
        updateFieldFeedback(field, errors[0]);
    } else {
        field.classList.remove('is-invalid');
        field.classList.add('is-valid');
        updateFieldFeedback(field, '');
    }
    
    return errors;
}

function validateForm(form) {
    const allErrors = [];
    const inputs = form.querySelectorAll('input[required], input[type="email"], input[type="tel"]');
    
    inputs.forEach(input => {
        const fieldErrors = validateField(input);
        allErrors.push(...fieldErrors);
    });
    
    return allErrors;
}

function displayValidationErrors(errors, summaryEl, errorsEl) {
    if (summaryEl && errorsEl) {
        errorsEl.innerHTML = errors.map(error => `<li>${error}</li>`).join('');
        summaryEl.classList.remove('d-none');
        summaryEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
}

function updateFieldFeedback(field, message) {
    let feedback = field.parentNode.querySelector('.invalid-feedback');
    if (!feedback) {
        feedback = document.createElement('div');
        feedback.className = 'invalid-feedback';
        field.parentNode.appendChild(feedback);
    }
    feedback.textContent = message;
}

function showFormLoading(button, isLoading) {
    if (!button) return;
    
    if (isLoading) {
        button.disabled = true;
        const originalText = button.innerHTML;
        button.dataset.originalText = originalText;
        button.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Processing...';
    } else {
        button.disabled = false;
        button.innerHTML = button.dataset.originalText || button.innerHTML;
    }
}

// Initialize tooltips (if using Bootstrap 5)
function initializeTooltips() {
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    if (typeof bootstrap !== 'undefined') {
        tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    }
}

// Add smooth animations
function initializeAnimations() {
    // Fade in animation for cards
    const cards = document.querySelectorAll('.card-style, .feature-card, .stat-card, .help-card');
    cards.forEach((card, index) => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        
        setTimeout(() => {
            card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
        }, index * 100);
    });
}

// ====== COUNTER ANIMATIONS ======
function initializeCounters() {
    const counters = document.querySelectorAll('.counter');
    
    const observerOptions = {
        threshold: 0.5,
        rootMargin: '0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                animateCounter(entry.target);
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);
    
    counters.forEach(counter => observer.observe(counter));
}

function animateCounter(element) {
    const target = parseInt(element.dataset.target) || parseInt(element.textContent);
    const duration = CONFIG.COUNTER_ANIMATION_DURATION;
    const start = 0;
    const increment = target / (duration / 16);
    let current = start;
    
    const timer = setInterval(() => {
        current += increment;
        if (current >= target) {
            element.textContent = target;
            clearInterval(timer);
        } else {
            element.textContent = Math.floor(current);
        }
    }, 16);
}

// ====== ADVANCED FILTERS ======
function initializeFilters() {
    const cityFilter = document.getElementById('cityFilter');
    const stateFilter = document.getElementById('stateFilter');
    
    if (cityFilter || stateFilter) {
        populateFilterOptions();
        
        [cityFilter, stateFilter].forEach(filter => {
            if (filter) {
                filter.addEventListener('change', applyFilters);
            }
        });
    }
}

function populateFilterOptions() {
    const cityFilter = document.getElementById('cityFilter');
    const stateFilter = document.getElementById('stateFilter');
    const rows = document.querySelectorAll('.student-row');
    
    const cities = new Set();
    const states = new Set();
    
    rows.forEach(row => {
        const cityEl = row.querySelector('.location-badge');
        const stateEl = row.querySelector('.state-text');
        
        if (cityEl) cities.add(cityEl.textContent.trim());
        if (stateEl) states.add(stateEl.textContent.trim());
    });
    
    // Populate city filter
    if (cityFilter) {
        Array.from(cities).sort().forEach(city => {
            const option = document.createElement('option');
            option.value = city;
            option.textContent = city;
            cityFilter.appendChild(option);
        });
    }
    
    // Populate state filter
    if (stateFilter) {
        Array.from(states).sort().forEach(state => {
            const option = document.createElement('option');
            option.value = state;
            option.textContent = state;
            stateFilter.appendChild(option);
        });
    }
}

function applyFilters() {
    const searchInput = document.getElementById('searchInput');
    const cityFilter = document.getElementById('cityFilter');
    const stateFilter = document.getElementById('stateFilter');
    
    const searchTerm = searchInput?.value.toLowerCase() || '';
    const selectedCity = cityFilter?.value || '';
    const selectedState = stateFilter?.value || '';
    
    const rows = document.querySelectorAll('.student-row');
    let visibleCount = 0;
    
    rows.forEach(row => {
        const cityEl = row.querySelector('.location-badge');
        const stateEl = row.querySelector('.state-text');
        const searchableText = getRowSearchableText(row);
        
        const cityMatch = !selectedCity || (cityEl && cityEl.textContent.trim() === selectedCity);
        const stateMatch = !selectedState || (stateEl && stateEl.textContent.trim() === selectedState);
        const searchMatch = !searchTerm || searchableText.includes(searchTerm);
        
        const isVisible = cityMatch && stateMatch && searchMatch;
        
        if (isVisible) {
            row.style.display = '';
            visibleCount++;
        } else {
            row.style.display = 'none';
        }
    });
    
    updateTableStats(visibleCount, rows.length);
    updateFilterInfo(searchTerm, selectedCity, selectedState, visibleCount, rows.length);
}

function clearAllFilters() {
    const searchInput = document.getElementById('searchInput');
    const cityFilter = document.getElementById('cityFilter');
    const stateFilter = document.getElementById('stateFilter');
    const filterInfo = document.getElementById('filterInfo');
    
    if (searchInput) searchInput.value = '';
    if (cityFilter) cityFilter.value = '';
    if (stateFilter) stateFilter.value = '';
    if (filterInfo) filterInfo.classList.add('d-none');
    
    // Show all rows
    const rows = document.querySelectorAll('.student-row');
    rows.forEach(row => {
        row.style.display = '';
    });
    
    updateTableStats(rows.length, rows.length);
    showToast('All filters cleared', 'info');
}

function updateFilterInfo(searchTerm, selectedCity, selectedState, visibleCount, totalCount) {
    const filterInfo = document.getElementById('filterInfo');
    const filterResultsText = document.getElementById('filterResultsText');
    
    if (!filterInfo || !filterResultsText) return;
    
    const hasFilters = searchTerm || selectedCity || selectedState;
    
    if (hasFilters) {
        let filterText = `Showing ${visibleCount} of ${totalCount} students`;
        const filters = [];
        
        if (searchTerm) filters.push(`matching "${searchTerm}"`);
        if (selectedCity) filters.push(`in ${selectedCity}`);
        if (selectedState) filters.push(`from ${selectedState}`);
        
        if (filters.length > 0) {
            filterText += ` ${filters.join(', ')}`;
        }
        
        filterResultsText.textContent = filterText;
        filterInfo.classList.remove('d-none');
        
        // Show filter status notification for better UX
        if (window.notifications) {
            const filterCount = filters.length;
            if (filterCount > 0) {
                notifications.info(`Applied ${filterCount} filter${filterCount > 1 ? 's' : ''} - ${visibleCount} results found`, { duration: 3000 });
            }
        }
    } else {
        filterInfo.classList.add('d-none');
    }
}

// ====== TABLE SORTING ======
function initializeTableSorting() {
    const sortableHeaders = document.querySelectorAll('.sortable');
    
    sortableHeaders.forEach(header => {
        header.addEventListener('click', () => {
            const column = header.dataset.column;
            const currentSort = header.dataset.sort || 'none';
            
            // Reset all other headers
            sortableHeaders.forEach(h => {
                if (h !== header) {
                    h.dataset.sort = 'none';
                    h.querySelector('.sort-icon').className = 'fas fa-sort sort-icon';
                }
            });
            
            // Update current header
            let newSort;
            if (currentSort === 'none' || currentSort === 'desc') {
                newSort = 'asc';
                header.querySelector('.sort-icon').className = 'fas fa-sort-up sort-icon';
            } else {
                newSort = 'desc';
                header.querySelector('.sort-icon').className = 'fas fa-sort-down sort-icon';
            }
            
            header.dataset.sort = newSort;
            sortTable(column, newSort);
        });
    });
}

function sortTable(column, direction) {
    const tbody = document.querySelector('#studentsTable tbody');
    const rows = Array.from(tbody.querySelectorAll('.student-row'));
    
    rows.sort((a, b) => {
        let aVal = getColumnValue(a, column);
        let bVal = getColumnValue(b, column);
        
        // Convert to numbers if possible
        const aNum = parseFloat(aVal);
        const bNum = parseFloat(bVal);
        
        if (!isNaN(aNum) && !isNaN(bNum)) {
            aVal = aNum;
            bVal = bNum;
        }
        
        if (direction === 'asc') {
            return aVal > bVal ? 1 : -1;
        } else {
            return aVal < bVal ? 1 : -1;
        }
    });
    
    // Re-append sorted rows
    rows.forEach(row => tbody.appendChild(row));
    
    showToast(`Table sorted by ${column} (${direction}ending)`, 'info');
}

function getColumnValue(row, column) {
    switch (column) {
        case 'name':
            return row.querySelector('.student-name')?.textContent.trim() || '';
        case 'email':
            return row.querySelector('.email-link')?.textContent.trim() || '';
        case 'city':
            return row.querySelector('.location-badge')?.textContent.trim() || '';
        case 'state':
            return row.querySelector('.state-text')?.textContent.trim() || '';
        case 'phone':
            return row.querySelector('.phone-link')?.textContent.trim() || '';
        case 'address':
            return row.querySelector('.address-text')?.textContent.trim() || '';
        default:
            return '';
    }
}

// ====== ENHANCED CONFIRMATION SYSTEM ======
// Replaced heavy modals with lightweight confirmation system
function confirmDeleteStudent(studentId, studentName, deleteUrl) {
    const message = `Are you sure you want to delete the student record for <strong>${studentName}</strong>? This action cannot be undone.`;
    
    if (window.notifications) {
        notifications.confirm(message, {
            title: 'Delete Student',
            confirmText: 'Delete',
            cancelText: 'Cancel',
            type: 'danger'
        }).then(confirmed => {
            if (confirmed) {
                // Show loading
                const loading = notifications.showLoading('Deleting student...', 'Please wait');
                
                // Perform deletion
                window.location.href = deleteUrl;
            }
        });
    } else {
        // Fallback to browser confirm
        if (confirm(`Are you sure you want to delete ${studentName}? This action cannot be undone.`)) {
            window.location.href = deleteUrl;
        }
    }
}

// ====== DATE AND TIME DISPLAY ======
function initializeDateDisplay() {
    const dateElements = document.querySelectorAll('#current-date');
    
    dateElements.forEach(element => {
        const now = new Date();
        const options = { 
            year: 'numeric', 
            month: 'short', 
            day: 'numeric'
        };
        element.textContent = now.toLocaleDateString('en-US', options);
    });
}

// ====== KEYBOARD SHORTCUTS ======
function initializeKeyboardShortcuts() {
    document.addEventListener('keydown', function(e) {
        // Ctrl/Cmd + K for search
        if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
            e.preventDefault();
            const searchInput = document.getElementById('searchInput');
            if (searchInput) {
                searchInput.focus();
                searchInput.select();
            }
        }
        
        // Ctrl/Cmd + N for new student
        if ((e.ctrlKey || e.metaKey) && e.key === 'n') {
            e.preventDefault();
            const addButton = document.querySelector('a[href="/supplier-add"]');
            if (addButton) {
                addButton.click();
            }
        }
        
        // Escape to clear search/filters
        if (e.key === 'Escape') {
            const searchInput = document.getElementById('searchInput');
            if (searchInput && searchInput === document.activeElement) {
                searchInput.blur();
                if (searchInput.value) {
                    clearAllFilters();
                }
            }
        }
    });
}

// ====== ENHANCED NOTIFICATION SYSTEM ======
// Legacy support for existing code - now uses enhanced notifications
function showToast(message, type = 'info', duration = CONFIG.NOTIFICATION_DURATION) {
    if (window.notifications) {
        notifications.show(message, type, { duration });
    } else {
        // Fallback to console if enhanced notifications not loaded
        console.log(`[${type.toUpperCase()}] ${message}`);
    }
}

// Legacy support
function showNotification(message, type = 'info') {
    showToast(message, type);
}

// Enhanced notification functions
function showSuccess(message, options = {}) {
    if (window.notifications) {
        return notifications.success(message, options);
    }
    return showToast(message, 'success');
}

function showError(message, options = {}) {
    if (window.notifications) {
        return notifications.error(message, options);
    }
    return showToast(message, 'error');
}

function showWarning(message, options = {}) {
    if (window.notifications) {
        return notifications.warning(message, options);
    }
    return showToast(message, 'warning');
}

function showInfo(message, options = {}) {
    if (window.notifications) {
        return notifications.info(message, options);
    }
    return showToast(message, 'info');
}

// ====== ENHANCED DATA EXPORT ======
function exportData() {
    const loadingOverlay = showLoadingOverlay();
    
    setTimeout(() => {
        try {
            const visibleRows = document.querySelectorAll('.student-row:not([style*="display: none"])');
            
            if (visibleRows.length === 0) {
                showToast('No student data to export', 'warning');
                hideLoadingOverlay(loadingOverlay);
                return;
            }
            
            // Prepare CSV data
            const headers = ['Name', 'Email', 'Phone', 'Address', 'City', 'State'];
            let csv = headers.join(',') + '\n';
            
            visibleRows.forEach(row => {
                const name = row.querySelector('.student-name')?.textContent.trim() || '';
                const email = row.querySelector('.email-link')?.textContent.replace(/.*?([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}).*/, '$1') || '';
                const phone = row.querySelector('.phone-link')?.textContent.replace(/.*?([\d\s\+\-\(\)]+).*/, '$1').trim() || '';
                const address = row.querySelector('.address-text')?.textContent.trim() || '';
                const city = row.querySelector('.location-badge')?.textContent.trim() || '';
                const state = row.querySelector('.state-text')?.textContent.trim() || '';
                
                const rowData = [name, email, phone, address, city, state].map(field => `"${field}"`);
                csv += rowData.join(',') + '\n';
            });
            
            // Create and download file
            const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
            const link = document.createElement('a');
            const url = URL.createObjectURL(blob);
            
            link.setAttribute('href', url);
            link.setAttribute('download', `students_export_${new Date().toISOString().split('T')[0]}.csv`);
            link.style.visibility = 'hidden';
            
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            
            hideLoadingOverlay(loadingOverlay);
            showToast(`Successfully exported ${visibleRows.length} student records`, 'success');
            
        } catch (error) {
            console.error('Export failed:', error);
            hideLoadingOverlay(loadingOverlay);
            showToast('Export failed. Please try again.', 'error');
        }
    }, 500);
}

// ====== REFRESH DATA ======
function refreshData() {
    const loadingOverlay = showLoadingOverlay('Refreshing student data...');
    
    // Animate refresh icon
    const refreshButtons = document.querySelectorAll('[onclick="refreshData()"] i');
    refreshButtons.forEach(icon => {
        icon.classList.add('fa-spin');
    });
    
    showToast('Refreshing student data...', 'info');
    
    setTimeout(() => {
        window.location.reload();
    }, 1500);
}

// ====== ENHANCED STUDENT FUNCTIONS ======
function showStudentDetails(id, name, email, phone, address, city, state) {
    const detailsHtml = `
        <div class="student-details-card" style="text-align: left;">
            <div class="row">
                <div class="col-md-6">
                    <h6><i class="fas fa-user me-2"></i>Personal Information</h6>
                    <p><strong>Name:</strong> ${name || 'N/A'}</p>
                    <p><strong>Email:</strong> ${email || 'N/A'}</p>
                    <p><strong>Phone:</strong> ${phone || 'N/A'}</p>
                </div>
                <div class="col-md-6">
                    <h6><i class="fas fa-map-marker-alt me-2"></i>Address Information</h6>
                    <p><strong>Address:</strong> ${address || 'N/A'}</p>
                    <p><strong>City:</strong> ${city || 'N/A'}</p>
                    <p><strong>State:</strong> ${state || 'N/A'}</p>
                </div>
            </div>
            <div class="mt-3 text-center">
                <a href="/supplier-update/${id}" class="btn btn-primary">
                    <i class="fas fa-edit me-2"></i>Edit Student
                </a>
            </div>
        </div>
    `;
    
    if (window.notifications) {
        notifications.confirm(detailsHtml, {
            title: `Student Details - ${name}`,
            confirmText: 'Close',
            cancelText: '',
            type: 'info'
        });
    } else {
        // Fallback: redirect to edit page
        window.location.href = `/supplier-update/${id}`;
    }
}

// Legacy support for old function name
function viewStudentModal(id, name, email, phone, address, city, state) {
    showStudentDetails(id, name, email, phone, address, city, state);
}

// Legacy function - now uses enhanced confirmation
function confirmDelete(studentId, studentName) {
    confirmDeleteStudent(studentId, studentName, `/supplier-remove/${studentId}`);
}

// ====== UTILITY FUNCTIONS ======
function updateTableStats(visibleCount, totalCount) {
    const showingStart = document.getElementById('showing-start');
    const showingEnd = document.getElementById('showing-end');
    const totalRecords = document.getElementById('total-records');
    const totalStudents = document.getElementById('total-students');
    
    if (showingStart) showingStart.textContent = visibleCount > 0 ? '1' : '0';
    if (showingEnd) showingEnd.textContent = visibleCount.toString();
    if (totalRecords) totalRecords.textContent = totalCount.toString();
    if (totalStudents) totalStudents.textContent = totalCount.toString();
}

function toggleNoResultsMessage(show) {
    const emptyRow = document.querySelector('.empty-row');
    if (emptyRow) {
        emptyRow.style.display = show ? '' : 'none';
    }
}

function showLoadingOverlay(message = 'Loading...') {
    let overlay = document.getElementById('loadingOverlay');
    
    if (!overlay) {
        overlay = document.createElement('div');
        overlay.id = 'loadingOverlay';
        overlay.className = 'loading-overlay';
        overlay.innerHTML = `
            <div class="loading-content">
                <div class="spinner-border text-primary mb-3" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
                <p class="text-muted" id="loadingMessage">${message}</p>
            </div>
        `;
        document.body.appendChild(overlay);
    } else {
        document.getElementById('loadingMessage').textContent = message;
    }
    
    overlay.classList.remove('d-none');
    return overlay;
}

function hideLoadingOverlay(overlay) {
    if (overlay) {
        overlay.classList.add('d-none');
    }
}

function capitalizeFirst(str) {
    return str.charAt(0).toUpperCase() + str.slice(1);
}

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// ====== ENHANCED STYLES ======
function addEnhancedStyles() {
    const style = document.createElement('style');
    style.textContent = `
        .is-invalid {
            border-color: #dc3545 !important;
            box-shadow: 0 0 0 0.2rem rgba(220, 53, 69, 0.25) !important;
            animation: shake 0.6s ease-in-out;
        }
        
        .is-valid {
            border-color: #198754 !important;
            box-shadow: 0 0 0 0.2rem rgba(25, 135, 84, 0.25) !important;
        }
        
        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            10%, 30%, 50%, 70%, 90% { transform: translateX(-2px); }
            20%, 40%, 60%, 80% { transform: translateX(2px); }
        }
        
        .highlight-row {
            background: linear-gradient(90deg, rgba(52, 152, 219, 0.1) 0%, rgba(52, 152, 219, 0.05) 100%) !important;
            transform: scale(1.01);
            box-shadow: 0 2px 8px rgba(52, 152, 219, 0.2);
            border-left: 4px solid #3498db;
            transition: all 0.3s ease;
        }
        
        .loading-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(255, 255, 255, 0.95);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 9999;
            backdrop-filter: blur(5px);
        }
        
        .loading-content {
            text-align: center;
            padding: 2rem;
            background: white;
            border-radius: 1rem;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
            min-width: 200px;
        }
        
        .fa-spin {
            animation: fa-spin 1s infinite linear;
        }
        
        @keyframes fa-spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        mark {
            background: linear-gradient(90deg, rgba(255, 235, 59, 0.8) 0%, rgba(255, 235, 59, 0.4) 100%);
            padding: 0.1em 0.2em;
            border-radius: 0.2em;
            font-weight: 600;
        }
        
        .toast {
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        /* Smooth animations for all interactive elements */
        .btn, .form-control, .card, .nav-link {
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        .btn:hover {
            transform: translateY(-1px);
        }
        
        .btn:active {
            transform: translateY(0);
        }
        
        /* Enhanced focus styles for accessibility */
        .btn:focus, .form-control:focus, .nav-link:focus {
            outline: 2px solid #3498db;
            outline-offset: 2px;
        }
        
        /* Custom scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
            height: 8px;
        }
        
        ::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 4px;
        }
        
        ::-webkit-scrollbar-thumb {
            background: linear-gradient(135deg, #3498db, #2980b9);
            border-radius: 4px;
        }
        
        ::-webkit-scrollbar-thumb:hover {
            background: linear-gradient(135deg, #2980b9, #21618c);
        }
    `;
    document.head.appendChild(style);
}

// ====== IMPROVED ERROR HANDLING ======
window.addEventListener('error', function(e) {
    console.error('JavaScript Error:', e.error);
    // Only show error notification in development mode
    if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
        console.warn('Development mode: Error caught but not displayed to user');
    }
    // Silently handle errors in production - no annoying popups
});

// ====== PERFORMANCE MONITORING ======
if ('performance' in window) {
    window.addEventListener('load', function() {
        const loadTime = performance.now();
        console.log(`🚀 Page loaded in ${Math.round(loadTime)}ms`);
        
        // Show performance info in console for development
        if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
            console.log('📊 Performance Metrics:', {
                'DOM Content Loaded': Math.round(performance.getEntriesByType('navigation')[0].domContentLoadedEventEnd),
                'Full Load Time': Math.round(loadTime),
                'Resources': performance.getEntriesByType('resource').length
            });
        }
    });
}

// ====== EXPORT GLOBAL FUNCTIONS FOR TEMPLATE USE ======
window.studentManagement = {
    showToast,
    showNotification,
    exportData,
    refreshData,
    viewStudentModal,
    confirmDelete,
    clearAllFilters,
    showLoadingOverlay,
    hideLoadingOverlay
};

console.log('✅ Student Management System JavaScript loaded successfully!');